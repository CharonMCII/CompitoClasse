package Esterno;

public class Prenotazione {

}
