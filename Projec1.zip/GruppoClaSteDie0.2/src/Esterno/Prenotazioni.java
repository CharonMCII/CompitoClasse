package Esterno;

public class Prenotazioni {

}
