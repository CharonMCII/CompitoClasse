package Esterno;

public class Data {

}
