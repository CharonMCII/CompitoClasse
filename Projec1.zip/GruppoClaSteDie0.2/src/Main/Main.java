package Main;

import Docente.Insegnante;
import Docente.Insegnamento;
import Esterno.Data;
import Esterno.Ora;
import Esterno.Prenotazione;
import Esterno.Prenotazioni;
import Scuola.Classe;
import Scuola.Laboratorio;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Laboratorio sistemi= new Laboratorio("Sistemi", 39, 5);
		
	}

}
