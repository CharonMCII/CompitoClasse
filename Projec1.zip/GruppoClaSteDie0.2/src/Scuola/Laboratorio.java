package Scuola;

public class Laboratorio {
	//attributi
	private String nomelab;
	private int capienza;
	private int piano;
	
	//costruttore
	public Laboratorio(String nomelab, int capienza, int piano) {
		setPiano(piano);
	}
	
	//metodi
	public void setNomeLab() {
		this.nomelab=nomelab;
	}
	public String getNomeLab() {
		return nomelab;
	}
	public void setCapienza() {
		boolean i;
		i=false;
		while(i=false) {
			this.capienza=capienza;
			if(capienza>10 && capienza<=40) {
				i=true;
			}
			else if(capienza>40) {
				System.out.println("Capienza massime superata!!");
			}
			else {
				System.out.println("Capienza minima insuficente!!");
			}
		}
		
	}
	public int getCapienza() {
		return capienza;
	}
	public void setPiano() {
		boolean i;
		i=false;
		while(!i) {
			this.piano=piano;
			if(piano>0 && piano<=3) {
				i=true;
			}
			else {
				System.out.println("Piano non Esistente!!");
			}
		}
		
	}
	public int getPiano() {
		return piano;
	}
}