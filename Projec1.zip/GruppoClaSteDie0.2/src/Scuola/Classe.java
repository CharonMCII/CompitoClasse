package Scuola;

public class Classe {
	//attributi
	private int anno;
	private String sezzione;
	private String indirizzo;
	private boolean i;
	
	//costruttore
	public Classe(int anno, String sezzione, string indirizzo) {
		setAnno(anno);
		setSezzione(sezzione);
		setIndirizzo(indirizzo);
	}
	
	//metodo
	public void setAnno() {
		i=false;
		while(i=false) {
			this.anno=anno;
			if(anno>0 && anno<=5) {
				i=true;
			}
			else {
				System.out.println("Anno non valido!!");
			}
		}
			
	}
	public void setSezzione() {
		this.sezzione=sezzione;
	}
	public void setIndirizzo() {
		this.indirizzo=indirizzo;
	}
	public int getAnno() {
		return anno;
	}
	public String getSezzione() {
		return sezzione;
	}
	public String getIndirizzo() {
		return indirizzo;
	}

}