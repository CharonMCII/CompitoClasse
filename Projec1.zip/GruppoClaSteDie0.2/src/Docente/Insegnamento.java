package Docente;

public class Insegnamento {

}
