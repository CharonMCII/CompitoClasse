package Docente;

public class Insegnante {

}
